# PROJETO SISTEMAS DISTRIBUÍDOS - META 1
 
 Para correr o programa compilado:
 - Abrir a pasta JAR
 - correr o comando "java -jar {filename}" para os 4 ficheiros,
 - sendo {filename} o nome do ficheiro
 - ordem de execução: SearchModule, ISB, Downloader, Client
 
 Para correr o programa através do código fonte:
 - Abrir o projeto Maven da pasta "ProjetoSD"
 - Correr, por ordem, os ficheiros: SearchModule.java, IndexStorageBarrel.java, Downloader.java ,RMIClient.java
 
 O projeto apresenta dependências externas: JSOUP
 