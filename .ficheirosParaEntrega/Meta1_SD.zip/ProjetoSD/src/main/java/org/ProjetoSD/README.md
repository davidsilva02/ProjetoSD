# ProjetoSD

Correr na seguinte ordem: SearchModule, IndexStorageBarrel (escrever nome do ficheiro que queremos armazenar a informacao dos barrels), Downloader, RMIClient, 